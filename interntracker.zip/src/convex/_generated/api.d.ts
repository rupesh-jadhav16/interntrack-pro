/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as admin from "../admin.js";
import type * as applications from "../applications.js";
import type * as attendance from "../attendance.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as certificates from "../certificates.js";
import type * as companies from "../companies.js";
import type * as consent from "../consent.js";
import type * as deadlines from "../deadlines.js";
import type * as enrollments from "../enrollments.js";
import type * as faculty from "../faculty.js";
import type * as feedback from "../feedback.js";
import type * as helpers from "../helpers.js";
import type * as http from "../http.js";
import type * as internships from "../internships.js";
import type * as notifications from "../notifications.js";
import type * as profiles from "../profiles.js";
import type * as reports from "../reports.js";
import type * as rewards from "../rewards.js";
import type * as seed from "../seed.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  applications: typeof applications;
  attendance: typeof attendance;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  certificates: typeof certificates;
  companies: typeof companies;
  consent: typeof consent;
  deadlines: typeof deadlines;
  enrollments: typeof enrollments;
  faculty: typeof faculty;
  feedback: typeof feedback;
  helpers: typeof helpers;
  http: typeof http;
  internships: typeof internships;
  notifications: typeof notifications;
  profiles: typeof profiles;
  reports: typeof reports;
  rewards: typeof rewards;
  seed: typeof seed;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
